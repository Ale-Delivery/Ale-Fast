import 'dart:math';

import 'package:flutter/foundation.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class AuthService {
  final SupabaseClient _supabase = Supabase.instance.client;

  static String _generateUserId() {
    final random = Random.secure();
    final bytes = List<int>.generate(16, (_) => random.nextInt(256));
    bytes[6] = (bytes[6] & 0x0f) | 0x40;
    bytes[8] = (bytes[8] & 0x3f) | 0x80;
    String hex(int b) => b.toRadixString(16).padLeft(2, '0');
    return '${bytes.sublist(0, 4).map(hex).join()}-'
        '${bytes.sublist(4, 6).map(hex).join()}-'
        '${bytes.sublist(6, 8).map(hex).join()}-'
        '${bytes.sublist(8, 10).map(hex).join()}-'
        '${bytes.sublist(10, 16).map(hex).join()}';
  }

  // 1. ඇත්තටම OTP verify කරන කොටස
  Future<void> loginWithPhone(String phone, String otp) async {
    await _supabase.auth.verifyOTP(
      phone: phone,
      token: otp,
      type: OtpType.sms,
    );
  }

  // 2. Dummy OTP එක යවන Function එක 
  Future<String> sendDummyOTP(String phoneNumber) async {
    await Future.delayed(const Duration(seconds: 2));
    
    String dummyOtp = "1234"; 
    
    print("=======================================");
    print("Mock SMS: Sent to $phoneNumber | OTP Code: $dummyOtp"); 
    print("=======================================");
    
    return dummyOtp; 
  }

  // 3. Profile save — Supabase sync is best-effort; always returns userId for local session.
  Future<String> saveUserProfile({
    required String name,
    String? email,
    String? gender,
    String? birthday,
    String? phone,
  }) async {
    final user = _supabase.auth.currentUser;
    final userId = user?.id ?? _generateUserId();

    final payload = <String, dynamic>{
      'id': userId,
      'name': name,
    };

    final trimmedEmail = email?.trim();
    if (trimmedEmail != null && trimmedEmail.isNotEmpty) {
      payload['email'] = trimmedEmail;
    }
    if (gender != null && gender.isNotEmpty) {
      payload['gender'] = gender;
    }
    if (birthday != null && birthday.isNotEmpty) {
      payload['birthday'] = birthday;
    }
    if (phone != null && phone.isNotEmpty) {
      payload['phone'] = phone;
    }

    try {
      await _supabase.from('Profiles').upsert(payload);
    } catch (e) {
      // Common when Profiles table is missing columns (birthday, phone) or RLS blocks insert.
      // App still continues with local profile — run supabase_schema.sql Profiles section.
      debugPrint('Profile Supabase sync skipped: $e');
      try {
        await _supabase.from('Profiles').upsert({
          'id': userId,
          'name': name,
        });
      } catch (e2) {
        debugPrint('Profile minimal sync failed: $e2');
      }
    }

    return userId;
  }
}